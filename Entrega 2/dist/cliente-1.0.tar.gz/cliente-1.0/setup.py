from setuptools import setup

setup (
    name='cliente',
    version= 1.0,
    description='Paquete para gestión de clientes',
    author='Marvin Cruz',
    author_email= 'mncsandoval@hotmail.com',
    packages=['modulos']
)